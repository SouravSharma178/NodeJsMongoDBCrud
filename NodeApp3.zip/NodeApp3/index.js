require("dotenv").config();
const express = require("express");
const server = express();
server.use(express.static(process.env.PUBLIC_DIR));

// Database connection
const mongoose = require("mongoose");
main().then(()=>{console.log("Database Connected!")}).catch((err) => console.log(err));
async function main() {
  await mongoose.connect("mongodb://127.0.0.1:27017/ecommerce");
  // use `await mongoose.connect('mongodb://user:password@127.0.0.1:27017/test');` if your database has auth enabled
  console.log("Database connected");
}


const productRouter = require("./routes/productRoute.js");
const userRouter = require("./routes/userRoute.js");
//console.log(productRouter)
// process.env.DB_PASSWORD = "YHXdz46zT7vnLq1d"
// console.log("Env",process.env.DB_PASSWORD)
server.use(express.json());
server.use("/users", userRouter.router);
server.use("/products", productRouter.router);

server.listen(process.env.PORT, () => {
  console.log("server started");
});
