// Schema
const mongoose = require("mongoose");
const { Schema } = mongoose;
const productSchema = new Schema({
  title: { type: String, required: [true, "Please provide a value for title"] },
  description: String,
  category: String,
  price: { type: Number, required: [true, "Please provide a value for price"] },
  discountPercentage: Number,
  rating: { type: Number, min: [1, "Min Rating"], max: [5, "Max Rating"] },
  stock: Number,
  tags: [String],
});

exports.Product = mongoose.model("Product", productSchema);
