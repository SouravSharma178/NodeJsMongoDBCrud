const fs = require("fs");
const { Product: Product } = require("../model/product.js");
// CREATE PRODUCT
exports.addProduct = async (req, res) => {
  const product = new Product(req.body);
  console.log("Data sent is", product);
  // instance of a model is a document {} and a document has multiple records
  //console.log(product)
  try {
    console.log("Inside Try");
    await product.save().then((doc) => console.log(".THEN", doc));
    res.status(201).json(product);
  } catch (err) {
    console.log("InsideCatchBlock:", err);
    res.status(400).json(err);
  }
};

exports.getAllProducts = async (req, res) => {
  const products = await Product.find();
  console.log(products);
  res.status(201).json(products);
};
exports.getProduct = async (req, res) => {
  const productId = req.params.id;
  const products = await Product.findById(productId);
  console.log(products);
  res.status(201).json(products);
};

exports.replaceProduct = async (req, res) => {
  const productId = req.params.id;
  try {
    const products = await Product.findOneAndReplace(
      { _id: productId },
      req.body,
      { new: true },
      { upsert: true }
    );
    console.log(products);
    res.status(201).json(products);
  } catch (err) {
    console.log(err);
    res.status(400).json(err);
  }
};

exports.updateProduct = async (req, res) => {
  const productId = req.params.id;
  try {
    const products = await Product.findOneAndUpdate(
      { _id: productId },
      req.body,
      { new: true },
      { upsert: true }
    );
    console.log(products);
    res.status(201).json(products);
  } catch (err) {
    console.log(err);
    res.status(400).json(err);
  }
};

exports.deleteProduct = async (req, res) => {
  const productId = req.params.id;
  try {
    const products = await Product.findOneAndDelete(
      { _id: productId },
      { new: true }
    );
    console.log(products);
    res.status(201).json(products);
  } catch (err) {
    console.log(err);
    res.status(400).json(err);
  }
};
