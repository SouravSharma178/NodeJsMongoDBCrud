const fs = require("fs");
const jsonData = JSON.parse(fs.readFileSync("data.json", "utf-8"));
exports.addUser = (req, res) => {
    const newUser = req.body;
    //console.log(newProduct)
    jsonData.users.push(newUser);
    //console.log(jsonData);
    res.status(201).send(newUser);
}
exports.getAllUsers = (req, res) => {
    //console.log(jsonData.users[0]);
    res.status(201).json(jsonData.users);
}
exports.getUser = (req, res) => {
    const userId = +req.params.id;
    const fetchedUser = jsonData.users.find((p) => p.id === userId);
    console.log(fetchedUser);
    res.status(201).json(fetchedUser);
 }
exports.updateUser = (req, res) => {
    const userId = +req.params.id;
    const fetchedUser = jsonData.users.findIndex((p) => p.id === userId);
    jsonData.users.splice(fetchedUser, 1, { ...req.body, id: userId });
    //console.log(modifiedArray)
    res.status(201).json(jsonData.users);
}
exports.replaceUser = (req, res) => {
    const userId = +req.params.id;
    const fetchedUser = jsonData.users.find((p) => p.id === userId);
    const fetchedUserIndex = jsonData.users.findIndex((p) => p.id === userId);
    jsonData.users.splice(fetchedUserIndex, 1, {...fetchedUser,...req.body,id: userId,});
    //console.log(modifiedArray)
    res.status(201).json(jsonData.users);
}
exports.deleteUser = (req, res) => {
    const userId = +req.params.id;
    const fetchedUser = jsonData.users.find((p) => p.id === userId);
    const fetchedUserIndex = jsonData.users.findIndex(
      (p) => p.id === userId
    );
    jsonData.users.splice(fetchedUserIndex, 1);
    //console.log(modifiedArray)
    res.status(201).json(fetchedUser);
}