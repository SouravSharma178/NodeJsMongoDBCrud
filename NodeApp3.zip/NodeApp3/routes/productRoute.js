const express = require("express");
const routes = express.Router();
const productController = require("../controller/product.js");

routes.post("/", productController.addProduct);
routes.get("/", productController.getAllProducts);
routes.get("/:id", productController.getProduct);
routes.put("/:id", productController.replaceProduct);
routes.patch("/:id", productController.updateProduct);
routes.delete("/:id", productController.deleteProduct);

exports.router = routes;