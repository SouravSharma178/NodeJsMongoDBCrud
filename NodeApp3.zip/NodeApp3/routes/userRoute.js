const express = require("express");
const routes = express.Router();
const userController = require("../controller/user.js");

routes.post("/", userController.addUser);
routes.get("/", userController.getAllUsers);
routes.get("/:id", userController.getUser);
routes.put("/:id", userController.replaceUser);
routes.patch("/:id", userController.updateUser);
routes.delete("/:id", userController.deleteUser);

exports.router = routes;